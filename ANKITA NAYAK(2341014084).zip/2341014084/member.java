package minorproj;
import java.util.*;
public class member {
//write constructor or setter methods and display method
	private int MemberID;
	private String LastName ;
	private String FirstName; 
	private int Handicap ;
	private char Gender ;
	private String Team; 
	private String MemberType ;
	private int Coach ;
	private long Phone ;
	private Date JoinDate;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int u=0;int v=0;int w=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the total number of members in the club");
		int n=sc.nextInt();
		member m[]=new member[n];
		int i;
		for( i=0;i<n;i++)
		{
			m[i]=new member();
			System.out.println("Enter the member Id(an integer) of the member");
			m[i].MemberID=sc.nextInt();
			System.out.println("Enter the LastName of the member");
			sc.nextLine();
			m[i].LastName=sc.nextLine();
			
			System.out.println("Enter the FirstName of the member");
			
			m[i].FirstName=sc.nextLine();
			System.out.println("Enter the Handicap level of the member");
			System.out.println("Low handicap: 0–10\r\n"+ "Mid-Handicap: 11–18\r\n"+ "High handicap: 19");
			m[i].Handicap=sc.nextInt();
			sc.nextLine();
			System.out.println("Enter the Gender(F/M) of the member");
			m[i].Gender=sc.nextLine().charAt(0);
			
			System.out.println("Enter the Team(A/B) of the member");
			m[i].Team=sc.nextLine();
			System.out.println("Enter the member type(senior(above 40)/junior) of the member");
			m[i].MemberType=sc.nextLine();
			System.out.println("Enter the Coach(153/235) of the member");
			m[i].Coach=sc.nextInt();
			System.out.println("Enter the Phone number of the member");
			m[i].Phone=sc.nextLong();
			System.out.println("Enter the date(1-31) of joining the member");
			int d=sc.nextInt();
			sc.nextLine();
			System.out.println("Enter the month(Jan or Feb or Mar or Apr,...,Dec) name of joining the member");
			String mon=sc.nextLine();
			System.out.println("Enter the year(example: 2005) of joining the member");
			int y=sc.nextInt();
			m[i].JoinDate=new Date(d,mon,y);
			
		}

		System.out.print("MemberID\t");
		System.out.print("LastName\t");
		System.out.print("FirstName\t");
		System.out.print("Handicap\t");
		System.out.print("Gender\t\t");
		System.out.print("Team\t\t");
		System.out.print("MemberType\t");
		System.out.print("Coach\t\t");
		System.out.print("Phone\t\t");
		System.out.print("Date\t");
		System.out.println();
		for(i=0;i<n;i++)
		{
		m[i].display();
		}
		System.out.println();
			//Display the records where the member’s JoinDate is earlier than 07-Apr-09.
		System.out.println("The records of the members who Joined before 07-Apr-09.");
		System.out.print("MemberID\t");
		System.out.print("LastName\t");
		System.out.print("FirstName\t");
		System.out.print("Handicap\t");
		System.out.print("Gender\t\t");
		System.out.print("Team\t\t");
		System.out.print("MemberType\t");
		System.out.print("Coach\t\t");
		System.out.print("Phone\t\t");
		System.out.print("Date\t");
		System.out.println();
			for(i=0;i<n;i++)
			{
				
				Date JD=m[i].JoinDate;
				if(JD.getYear()<2009)
				{
					u=1;
					m[i].display();
				}
				if(JD.getYear()==2009)
				{
				if(JD.getMonth().equals("Jan")||JD.getMonth().equals("Feb")||JD.getMonth().equals("Mar"))
				{
					u=1;
					m[i].display();
				}
				if(JD.getMonth().equals("Apr"))
				{
					if(JD.getDay()<9)
					{
						u=1;
						m[i].display();
					}
				}
				}
			}
			if(u==0)
			{
				System.out.print("none"+"\t\t");
				System.out.print("none"+"\t\t");
				System.out.print("none"+"\t\t");
				System.out.print("none"+"\t\t");
				System.out.print("none"+"\t\t");
				System.out.print("none"+"\t\t");
				System.out.print("none"+"\t\t");
				System.out.print("none"+"\t\t");
				System.out.print("none"+"\t\t");
			}
			System.out.println();
//Display the records of all senior members whose handicap score is less than 12.
			
			System.out.println("The records of senior members whose handicap score is less than 12.");
			
			System.out.print("MemberID\t");
			System.out.print("LastName\t");
			System.out.print("FirstName\t");
			System.out.print("Handicap\t");
			System.out.print("Gender\t\t");
			System.out.print("Team\t\t");
			System.out.print("MemberType\t");
			System.out.print("Coach\t\t");
			System.out.print("Phone\t\t");
			System.out.print("Date\t");
			System.out.println();
			for(i=0;i<n;i++)
			{
				
				if(m[i].MemberType.equals("senior"))
				{
					if(m[i].Handicap<12)
					{
						v=1;
						m[i].display();
					}
				}
			}
			if(v==0)
			{
				System.out.print("none"+"\t\t");
				System.out.print("none"+"\t\t");
				System.out.print("none"+"\t\t");
				System.out.print("none"+"\t\t");
				System.out.print("none"+"\t\t");
				System.out.print("none"+"\t\t");
				System.out.print("none"+"\t\t");
				System.out.print("none"+"\t\t");
				System.out.print("none"+"\t\t");
			}
			System.out.println();
//Display the records of all the female senior members who are part of TeamB. 
			System.out.println("The records of all the female senior members who are part of TeamB.");
			
			System.out.print("MemberID\t");
			System.out.print("LastName\t");
			System.out.print("FirstName\t");
			System.out.print("Handicap\t");
			System.out.print("Gender\t\t");
			System.out.print("Team\t\t");
			System.out.print("MemberType\t");
			System.out.print("Coach\t\t");
			System.out.print("Phone\t\t");
			System.out.print("Date\t");
			System.out.println();
			for(i=0;i<n;i++)
			{
				if(m[i].Gender=='F'&&m[i].MemberType.equals("senior")&&m[i].Team.equals("B"))
				{
					w=1;
					m[i].display();
				}
			}
		
			if(w==0)
			{
				System.out.print("none"+"\t\t");
				System.out.print("none"+"\t\t");
				System.out.print("none"+"\t\t");
				System.out.print("none"+"\t\t");
				System.out.print("none"+"\t\t");
				System.out.print("none"+"\t\t");
				System.out.print("none"+"\t\t");
				System.out.print("none"+"\t\t");
				System.out.print("none"+"\t\t");
				System.out.print("none"+"\t\t");
			}
		
	}
	public void display()
	{
		System.out.print(MemberID+"\t\t");
		System.out.print(LastName+"\t\t");
		System.out.print(FirstName+"\t\t");
		System.out.print(Handicap+"\t\t");
		System.out.print(Gender+"\t\t");
		System.out.print(Team+"\t\t");
		System.out.print(MemberType+"\t\t");
		System.out.print(Coach+"\t\t");
		System.out.print(Phone+"\t\t");
		JoinDate.display();
	}
	

}
