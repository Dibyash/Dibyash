package minorproj;

public class Date {

	private int day;
	private String month ;
	private int year;
	Date(int day,String month,int year)
	{
		this.setDay(day);
		this.setMonth(month);
		this.setYear(year);
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day = day;
	}
	public void display()
	{
		System.out.println(day+"-"+month+"-"+year);
	}
}
